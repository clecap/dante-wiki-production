This file is the README file for the dante delta code.

The repository clecap/dante-delta contains some of the patches and amendments which have to be added
to MediaWiki to convert it into a DanteWiki.

## LICENSE

The files in here are Copyright (C) Clemens H. Cap 2023

Use is permitted according to a negotiated license or according
to the AGPL-3.0-ONLY License.