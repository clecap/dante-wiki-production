ALTER TABLE /*_*/watchlist
  MODIFY wl_notificationtimestamp BINARY(14) DEFAULT NULL;
