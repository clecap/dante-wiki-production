ALTER TABLE /*_*/site_identifiers DROP KEY /*i*/site_ids_type, ADD PRIMARY KEY (si_type,si_key);
