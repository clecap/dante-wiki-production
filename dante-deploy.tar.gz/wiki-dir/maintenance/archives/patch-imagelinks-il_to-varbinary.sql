ALTER TABLE /*_*/imagelinks MODIFY il_to VARBINARY(255) NOT NULL default '';
